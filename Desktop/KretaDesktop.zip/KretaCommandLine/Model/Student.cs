﻿using KretaCommandLine.Model.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KretaCommandLine.Model
{
    public class Student : Person
    {
    }
}
