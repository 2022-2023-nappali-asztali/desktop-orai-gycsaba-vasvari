# Záródolgozat - desktop applikáció
